package com.BookStore;
import java.util.Scanner;
	public class BookStoreMain {

		public static void main(String[] args) {
			System.out.println("Welcome to Mukta's Book Shop");
			Scanner in = new Scanner(System.in);
			try  {
				while(true)
				{
					System.out.println("1.Show Available Books");
					System.out.println("2.Buy Books");
					System.out.println("3.update Books");
					
					
					System.out.println("Enter your Choice");
					int ch=in.nextInt();
					
					switch(ch)
					{
					case 1 : 
							System.out.println("Available Books :");
							Operations.showBooks();
							break;
					case 2 : 
						System.out.println("Buy Books :");
						Operations.buyBooks();
						break;
						
					case 3 : 
						System.out.println("update Books :");
						Operations.updateBooks();
						break;
							
					default :System.out.println("Invalid Input"); 
					}
					System.out.println("Write 'no' or 'NO' to terminate,Write anything to continue");
					String choice=in.next();
					if(choice.equals("no")){
						break;
					}
				
				}
			}catch(Exception e) {
				e.printStackTrace();
				}
	
		}
	}
	
