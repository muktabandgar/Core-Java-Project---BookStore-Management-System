package com.BookStore;

	import java.sql.Connection;
	import java.sql.DriverManager;

	public class Connections
	{
		private static String driver="com.mysql.cj.jdbc.Driver";
		private static String ur="root";
		private static String pw="Punam@123";
		private static String url="jdbc:mysql://localhost:3306/bookstore";
		private static Connection con=null;
		
		public static Connection myConnection()
		{
			try
			{
				Class.forName(driver);
				con=DriverManager.getConnection(url,ur,pw);
			
			if(con==null)
			{
				System.out.println("Error in connection");
				System.exit(0);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}	
	}

