package com.BookStore;

	import java.sql.Connection;
	import java.sql.Statement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.Scanner;

	public class Operations {

		  private static Connection con;
		  private static Statement st;
		  private static ResultSet rs;
		  
		  
		public static void showBooks() {
			try
			  {
			    
				con=Connections.myConnection();	
					st=con.createStatement();
					String s="select * from bookstore";
					 rs=st.executeQuery(s);
					
					System.out.println("BOOK_ID\tBOOK_NAME\tAUTHOR_NAME\tQUANTITY\tBOOK_PRICE");
					
					if(rs.next()) 	
					{
						 rs=st.executeQuery(s);
						while(rs.next()) {
						System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t\t"+rs.getString(3)+"\t\t"+rs.getInt(4)+"\t\t"+rs.getInt(5));
					}
					}
					else {
						System.out.println("No books are available");
					}
			   }catch(Exception e) {
				   e.printStackTrace();
			   }
		}
		

		public static void buyBooks() {
			Scanner in=new Scanner(System.in);
			System.out.println("Enter which book you want to Buy");
			String bn=in.next();
			String s="select * from bookstore where book_name= '"+bn+"'";
			try {
				con=Connections.myConnection();	
				st=con.createStatement();
				rs=st.executeQuery(s);
				if(rs.next()) {
					System.out.println("Price = "+rs.getInt(5));
					int price=rs.getInt(5);
					int qn =rs.getInt(4);
					System.out.println("Enter Quantity : ");
					
					int q=in.nextInt();
					if(q>qn) {
						System.out.println("Out of Stock");
					}
					else {
						System.out.println("Purchase Completed");
						int bill=rs.getInt(5);
						int total=bill*q;
						System.out.println("Total amount="+total);
						
						
						int av=qn-q;
						if(av==0) 
						{
							String del="Delete from bookstore where book_name='"+bn+"'";
						
						int i=st.executeUpdate(del);
						
						}
						else {
							String up="update bookstore set quantity="+av+" where book_name='"+bn+"'";
							int i=st.executeUpdate(up);

						}
					}
			}
				else {
					System.out.println("Out of stock");
				}
			}
				catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		public static void updateBooks() {
			Scanner in=new Scanner(System.in);
System.out.println("Enter 1 to insert book");
System.out.println("Enter 2 to update price");


int ch=in.nextInt();
switch(ch) {
case 1:
		insertBook();
		break;
case 2:
		try {
			con=Connections.myConnection();	
			st=con.createStatement();
			System.out.println("Enter book id");
			int bid=in.nextInt();
			System.out.println("Enter new price");
			
			int price=in.nextInt();
			
			String up="update BookStore set BOOK_PRICE="+price+" where  BOOK_ID="+bid;
			st.executeUpdate(up);
			
		}catch(Exception e) {
			e.printStackTrace();
	
	}
		break;

}
			
		}
public static void insertBook() {
	Scanner in=new Scanner(System.in);
	System.out.println("Enter your book Id:");
	int bid=in.nextInt();
	System.out.println("Enter Your Book Name:");
	String bn=in.next();
	
	System.out.println("Enter Author Name:");
	String an=in.next();
	System.out.println("Enter book quantity:");
	int q=in.nextInt();
	
	System.out.println("Enter the price:");
	int pr=in.nextInt();
	
	String up="insert into bookstore values('"+bid+"','"+bn+"','"+an+"','"+q+"','"+pr+"')";
	try {
		con=Connections.myConnection();	
		st=con.createStatement();
		int i=st.executeUpdate(up);
		
		if(i>0) {
			System.out.println("Books updated");
		}
		else {
			System.out.println("Books are not updated");
		}
	} catch (SQLException e) {

		e.printStackTrace();
	}
}
		

	}


